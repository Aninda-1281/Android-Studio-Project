package com.example.project1.listeners;

import com.example.project1.models.User;

public interface UserListener {

    void onUserClicked(User user);

}
